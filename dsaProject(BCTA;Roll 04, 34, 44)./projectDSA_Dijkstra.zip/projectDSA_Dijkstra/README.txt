PROJECT INFORMATION:

(DEMONSTRATION OF SHORTEST PATH FINDING APP BASED ON 'DIJKSTRA's ALGORITHM')

PROGRAMMING LANGUAGE USED   : C++ 
RESULT    			    : A WIN32 CONSOLE APPLICATION

COMPATIBILITY		    :
	Tested on Windows 10/64 Bit,
		    Windows 11/64 Bit

	Should work on systems running Windows XP/32 Bit and newer windows Ver.

	[NOT COMPATIBLE FOR ANY LINUX DISTRIBUTIONS]
	Program uses several libraries available exclusively on Windows
	To Run the Program in Linux, a Windows Emulator like Wine can 
	be used although, there is no guarentee that the code will work
	as expected in a virtual environment.

DESCRIPTION:
	A simple yet effective effort to make an efficient shortest path
finding application. The program uses array implementation of Graph Data
structure to then be used in the Djikstra's Algorithm in order to perform
its function. 


CREATORS OF THIS PROJECT:
	Biswash Khanal
	BCT A, Roll: 34
	biswashkhanal67@gmail.com

	Kabin Giri
	BCT A, Roll: 44
	girikabin505@gmail.com

	Aayush Basnet
	BCT A, Roll: 04
	
	

